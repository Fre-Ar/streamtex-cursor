from typing import List, Tuple, Optional, Type, Union
import re

theme = None

def add_css(str1: str, str2: str):
    if str1 and str2:
         return str1 + "; " + str2
    elif str1:
         return str1
    else:
         return str2
    
def remove_css(str1: str, str2: str):
    # Split CSS strings into lists of properties
    props1 = [prop.strip() for prop in str1.split(';') if prop.strip()]
    props2 = [prop.strip() for prop in str2.split(';') if prop.strip()]

    # Extract property names from props2
    prop_names2 = set()
    for prop in props2:
        match = re.match(r'^([^:]+):', prop)
        if match:
            prop_name = match.group(1).strip()
            prop_names2.add(prop_name)

    # Remove properties from props1 that are in prop_names2
    new_props1 = []
    for prop in props1:
        match = re.match(r'^([^:]+):', prop)
        if match:
            prop_name = match.group(1).strip()
            if prop_name not in prop_names2:
                new_props1.append(prop)
        else:
            # Keep properties without a colon (malformed)
            new_props1.append(prop)

    return '; '.join(new_props1)

class Style:
    """Defines a style, encapsulating a string of (maybe) multiple css in-line styles"""
    def __init__(self, css:str, theme_css: dict={}, id:str=""):
        self.id = id
        self.css = css
        self.theme_css = theme_css

     # Define addition
    def __add__(self, other):
        if isinstance(other, Style):
            
            # Merge theme_css dictionaries
            new_theme_css = {
                key: add_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            # Combine two Style objects
            return Style( add_css(self.css,  other.css), new_theme_css)
        elif isinstance(other, str):
            # Combine Style object with a string (CSS string)
            return Style( add_css(self.css, other), self.theme_css)
        return NotImplemented

    # Define reverse addition
    def __radd__(self, other):
        if isinstance(other, str):
            # Allow a string to be added before a Style object
            return Style( add_css( other, self.css), self.theme_css)
        return NotImplemented
    
    # Define subtraction
    def __sub__(self, other):
        if isinstance(other, Style):
            # Remove other.css from self.css
            new_css = remove_css(self.css, other.css)
                        # Subtract theme_css dictionaries
            new_theme_css = {
                key: remove_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }

            return Style(new_css, new_theme_css)
        elif isinstance(other, str):
            # Remove CSS string from self.css
            new_css = remove_css(self.css, other)
            return Style(new_css, self.theme_css)
        return NotImplemented

    # Define reverse subtraction
    def __rsub__(self, other):
        if isinstance(other, str):
            # Remove self.css from other CSS string
            new_css = remove_css(other, self.css)
            return Style(new_css, self.theme_css)
        return NotImplemented
    
    def __bool__(self):
        # Return False if the css string is empty or only whitespace
        return bool(self.css.strip())
    
    def __repr__(self):
        # Return the thematic style, otherwise the default css
        return self.theme_css.get(theme, self.css) 

class ListStyle(Style):
    """Defines a style for lists, including CSS and custom list symbols for styling levels."""
    def __init__(self, css: str = "", theme_css: dict = {}, symbols: List[str] = ["●"]):
        super().__init__(css, theme_css)
        self.symbols = symbols

    # Define addition
    def __add__(self, other):
        if isinstance(other, Style):
            # Combine two Style objects, including theme_css and symbols
            new_css = add_css(self.css, other.css)
            new_theme_css = {
                key: add_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            new_symbols = self.symbols + (other.symbols if isinstance(other, ListStyle) else [])
            return ListStyle(new_css, new_theme_css, new_symbols)
        elif isinstance(other, str):
            # Combine ListStyle with a CSS string
            return ListStyle(add_css(self.css, other), self.theme_css, self.symbols)
        return NotImplemented

    # Define reverse addition
    def __radd__(self, other):
        if isinstance(other, str):
            # Allow a string to be added before a ListStyle object
            return ListStyle(add_css(other, self.css), self.theme_css, self.symbols)
        return NotImplemented

    # Define subtraction
    def __sub__(self, other):
        if isinstance(other, Style):
            # Remove other.css from self.css and handle theme_css and symbols
            new_css = remove_css(self.css, other.css)
            new_theme_css = {
                key: remove_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            new_symbols = [s for s in self.symbols if not (isinstance(other, ListStyle) and s in other.symbols)]
            return ListStyle(new_css, new_theme_css, new_symbols)
        elif isinstance(other, str):
            # Remove a CSS string from self.css
            return ListStyle(remove_css(self.css, other), self.theme_css, self.symbols)
        return NotImplemented

    # Define reverse subtraction
    def __rsub__(self, other):
        if isinstance(other, str):
            # Remove self.css from another CSS string
            return ListStyle(remove_css(other, self.css), self.theme_css, self.symbols)
        return NotImplemented

    def lvl(self, lvl: int = 1):
        """
        Get the list-style type CSS for a specific level.
        Cycles through the symbols if the level exceeds the number of symbols.
        """
        index = (lvl - 1) % len(self.symbols)
        return f"list-style-type: '{self.symbols[index]}';"

class StyleGrid:
    """
    Defines a grid of styles that will be applied to the rows/columns of a table or grid.
    """

    def __init__(self, css_grid: List[List[Style]] = []):
        self.css_grid = css_grid

    def __add__(self, other):
        """
        Overlapping styles are added in the order of the style grids addition.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s1 + s2)
        
        elif isinstance(other, list):
            return self + StyleGrid(other)
        
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse addition: other + self
            return other + self
        
        elif isinstance(other, list):
            return StyleGrid(other) + self
        
        return NotImplemented
    

    def __sub__(self, other):
        """
        Overlapping styles are subtracted in the order of the style grids subtraction.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s1 - s2)
        elif isinstance(other, list):
            return self - StyleGrid(other)
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse subtraction: other - self
            return other - self
        elif isinstance(other, list):
            return StyleGrid(other) - self
        return NotImplemented

    def __mul__(self, other):
        """
        Multiplication works like addition but styles at the same cell are replaced.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s2 if s2 else s1)
        elif isinstance(other, list):
            return self * StyleGrid(other)
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse multiplication: other * self
            return other * self    
        elif isinstance(other, list):
            return StyleGrid(other) * self
        return NotImplemented

    def _combine_with(self, other, combine_styles):
        """
        Combines two StyleGrids using the provided combine_styles function for overlapping cells.
        """
        self_rows, self_cols = self._get_dimensions()
        other_rows, other_cols = other._get_dimensions()

        max_rows = max(self_rows, other_rows)
        max_cols = max(self_cols, other_cols)

        # Initialize new grid with Styles.none
        new_grid = [[StreamTeX_Styles.none for _ in range(max_cols)] for _ in range(max_rows)]

        # Fill in styles from self
        for i in range(self_rows):
            for j in range(len(self.css_grid[i])):
                new_grid[i][j] = self.css_grid[i][j]

        # Combine styles from other
        for i in range(other_rows):
            for j in range(len(other.css_grid[i])):
                if i < max_rows and j < max_cols:
                    new_grid[i][j] = combine_styles(new_grid[i][j], other.css_grid[i][j])

        return StyleGrid(new_grid)

    def _get_dimensions(self) -> Tuple[int, int]:
        if not self.css_grid:
            return 0, 0
        num_rows = len(self.css_grid)
        num_cols = max(len(row) for row in self.css_grid) if self.css_grid else 0
        return num_rows, num_cols

    @staticmethod
    def create(cells: str, style: Style, num_rows: Optional[int] = None, num_cols: Optional[int] = None):
        """
        Creates a StyleGrid with the specified cells filled with the given style.
        Cells are specified in Excel-like notation (e.g., "A1:C3,B5").
        Other cells are filled with Styles.none.
        """
        # Parse the cells string to get the list of cell indices
        cells_list = StyleGrid._parse_cells(cells)

        # Determine the required grid size
        max_row_index = max((row for row, _ in cells_list), default=0)
        max_col_index = max((col for _, col in cells_list), default=0)

        # Adjust grid size based on provided num_rows and num_cols
        grid_rows = max(num_rows if num_rows is not None else 0, max_row_index + 1)
        grid_cols = max(num_cols if num_cols is not None else 0, max_col_index + 1)

        # Initialize the grid with Styles.none
        grid = [[StreamTeX_Styles.none for _ in range(grid_cols)] for _ in range(grid_rows)]

        # Fill in the specified cells with the given style
        for row, col in cells_list:
            if row < grid_rows and col < grid_cols:
                grid[row][col] = style

        return StyleGrid(grid)

    @staticmethod
    def _parse_cells(cells_str: str) -> List[Tuple[int, int]]:
        """
        Parses a string of cell ranges in Excel-like notation and returns a list of cell indices.
        """
        cells = []
        ranges = cells_str.split(',')
        for cell_range in ranges:
            cell_range = cell_range.strip()
            if ':' in cell_range:
                start_cell, end_cell = cell_range.split(':')
                start_row, start_col = StyleGrid._cell_to_indices(start_cell.strip())
                end_row, end_col = StyleGrid._cell_to_indices(end_cell.strip())

                # Swap if start is after end
                if start_row > end_row:
                    start_row, end_row = end_row, start_row
                if start_col > end_col:
                    start_col, end_col = end_col, start_col

                for row in range(start_row, end_row + 1):
                    for col in range(start_col, end_col + 1):
                        cells.append((row, col))
            else:
                row, col = StyleGrid._cell_to_indices(cell_range)
                cells.append((row, col))
        return cells

    @staticmethod
    def _cell_to_indices(cell: str) -> Tuple[int, int]:
        """
        Converts a cell reference (e.g., "A1") to zero-based (row, col) indices.
        """
        match = re.match(r'^([A-Za-z]+)([0-9]+)$', cell)
        if not match:
            raise ValueError(f"Invalid cell reference: {cell}")
        col_str, row_str = match.groups()
        col_index = StyleGrid._column_letter_to_index(col_str)
        row_index = int(row_str) - 1  # Convert to zero-based index
        return row_index, col_index

    @staticmethod
    def _column_letter_to_index(col_str: str) -> int:
        """
        Converts column letters to a zero-based column index.
        """
        col_str = col_str.upper()
        col_index = 0
        for char in col_str:
            if 'A' <= char <= 'Z':
                col_index = col_index * 26 + (ord(char) - ord('A') + 1)
            else:
                raise ValueError(f"Invalid column letter: {char}")
        return col_index - 1  # Convert to zero-based index



class Decors:
            # Font decoration
            italic_text = Style("font-style: italic;")
            underline_text = Style("text-decoration: underline;")
            decor_none_text = Style("text-decoration: none;")

class Weights:
            # Font weights
            bold_weight = Style("font-weight: bold;")
            light_weight = Style("font-weight: 300;")
            normal_weight = Style("font-weight: normal;")

class Alignments:
            # Text alignment (how multi-line text is aligned, not where it is positioned)
            center_align = Style("text-align: center;")
            right_align = Style("text-align: right;")
            left_align = Style("text-align: left;")
            justify_align = Style("text-align: justify;")

class Colors:
    # Basic color styles
    reset = Style("color: initial;")
    alice_blue = Style("color: rgb(0, 255, 255);")
    antique_white = Style("color: AntiqueWhite;")
    aqua = Style("color: Aqua;")
    aquamarine = Style("color: Aquamarine;")
    azure = Style("color: Azure;")
    beige = Style("color: Beige;")
    bisque = Style("color: Bisque;")
    black = Style("color: Black;")
    blanched_almond = Style("color: BlanchedAlmond;")
    blue = Style("color: Blue;")
    blue_violet = Style("color: BlueViolet;")
    brown = Style("color: Brown;")
    burly_wood = Style("color: BurlyWood;")
    cadet_blue = Style("color: CadetBlue;")
    chartreuse = Style("color: Chartreuse;")
    chocolate = Style("color: Chocolate;")
    coral = Style("color: Coral;")
    cornflower_blue = Style("color: CornflowerBlue;")
    cornsilk = Style("color: Cornsilk;")
    crimson = Style("color: Crimson;")
    cyan = Style("color: Cyan;")
    dark_blue = Style("color: DarkBlue;")
    dark_cyan = Style("color: DarkCyan;")
    dark_golden_rod = Style("color: DarkGoldenRod;")
    dark_gray = Style("color: DarkGray;")
    dark_grey = Style("color: DarkGrey;")
    dark_green = Style("color: DarkGreen;")
    dark_khaki = Style("color: DarkKhaki;")
    dark_magenta = Style("color: DarkMagenta;")
    dark_olive_green = Style("color: DarkOliveGreen;")
    dark_orange = Style("color: DarkOrange;")
    dark_orchid = Style("color: DarkOrchid;")
    dark_red = Style("color: DarkRed;")
    dark_salmon = Style("color: DarkSalmon;")
    dark_sea_green = Style("color: DarkSeaGreen;")
    dark_slate_blue = Style("color: DarkSlateBlue;")
    dark_slate_gray = Style("color: DarkSlateGray;")
    dark_slate_grey = Style("color: DarkSlateGrey;")
    dark_turquoise = Style("color: DarkTurquoise;")
    dark_violet = Style("color: DarkViolet;")
    deep_pink = Style("color: DeepPink;")
    deep_sky_blue = Style("color: DeepSkyBlue;")
    dim_gray = Style("color: DimGray;")
    dim_grey = Style("color: DimGrey;")
    dodger_blue = Style("color: DodgerBlue;")
    fire_brick = Style("color: FireBrick;")
    floral_white = Style("color: FloralWhite;")
    forest_green = Style("color: ForestGreen;")
    fuchsia = Style("color: Fuchsia;")
    gainsboro = Style("color: Gainsboro;")
    ghost_white = Style("color: GhostWhite;")
    gold = Style("color: Gold;")
    golden_rod = Style("color: GoldenRod;")
    gray = Style("color: Gray;")
    grey = Style("color: Grey;")
    green = Style("color: Green;")
    green_yellow = Style("color: GreenYellow;")
    honey_dew = Style("color: HoneyDew;")
    hot_pink = Style("color: HotPink;")
    indian_red = Style("color: IndianRed;")
    indigo = Style("color: Indigo;")
    ivory = Style("color: Ivory;")
    khaki = Style("color: Khaki;")
    lavender = Style("color: Lavender;")
    lavender_blush = Style("color: LavenderBlush;")
    lawn_green = Style("color: LawnGreen;")
    lemon_chiffon = Style("color: LemonChiffon;")
    light_blue = Style("color: LightBlue;")
    light_coral = Style("color: LightCoral;")
    light_cyan = Style("color: LightCyan;")
    light_golden_rod_yellow = Style("color: LightGoldenRodYellow;")
    light_gray = Style("color: LightGray;")
    light_grey = Style("color: LightGrey;")
    light_green = Style("color: LightGreen;")
    light_pink = Style("color: LightPink;")
    light_salmon = Style("color: LightSalmon;")
    light_sea_green = Style("color: LightSeaGreen;")
    light_sky_blue = Style("color: LightSkyBlue;")
    light_slate_gray = Style("color: LightSlateGray;")
    light_slate_grey = Style("color: LightSlateGrey;")
    light_steel_blue = Style("color: LightSteelBlue;")
    light_yellow = Style("color: LightYellow;")
    lime = Style("color: Lime;")
    lime_green = Style("color: LimeGreen;")
    linen = Style("color: Linen;")
    magenta = Style("color: Magenta;")
    maroon = Style("color: Maroon;")
    medium_aqua_marine = Style("color: MediumAquaMarine;")
    medium_blue = Style("color: MediumBlue;")
    medium_orchid = Style("color: MediumOrchid;")
    medium_purple = Style("color: MediumPurple;")
    medium_sea_green = Style("color: MediumSeaGreen;")
    medium_slate_blue = Style("color: MediumSlateBlue;")
    medium_spring_green = Style("color: MediumSpringGreen;")
    medium_turquoise = Style("color: MediumTurquoise;")
    medium_violet_red = Style("color: MediumVioletRed;")
    midnight_blue = Style("color: MidnightBlue;")
    mint_cream = Style("color: MintCream;")
    misty_rose = Style("color: MistyRose;")
    moccasin = Style("color: Moccasin;")
    navajo_white = Style("color: NavajoWhite;")
    navy = Style("color: Navy;")
    old_lace = Style("color: OldLace;")
    olive = Style("color: Olive;")
    olive_drab = Style("color: OliveDrab;")
    orange = Style("color: Orange;")
    orange_red = Style("color: OrangeRed;")
    orchid = Style("color: Orchid;")
    pale_golden_rod = Style("color: PaleGoldenRod;")
    pale_green = Style("color: PaleGreen;")
    pale_turquoise = Style("color: PaleTurquoise;")
    pale_violet_red = Style("color: PaleVioletRed;")
    papaya_whip = Style("color: PapayaWhip;")
    peach_puff = Style("color: PeachPuff;")
    peru = Style("color: Peru;")
    pink = Style("color: Pink;")
    plum = Style("color: Plum;")
    powder_blue = Style("color: PowderBlue;")
    purple = Style("color: Purple;")
    rebecca_purple = Style("color: RebeccaPurple;")
    red = Style("color: Red;")
    rosy_brown = Style("color: RosyBrown;")
    royal_blue = Style("color: RoyalBlue;")
    saddle_brown = Style("color: SaddleBrown;")
    salmon = Style("color: Salmon;")
    sandy_brown = Style("color: SandyBrown;")
    sea_green = Style("color: SeaGreen;")
    sea_shell = Style("color: SeaShell;")
    sienna = Style("color: Sienna;")
    silver = Style("color: Silver;")
    sky_blue = Style("color: SkyBlue;")
    slate_blue = Style("color: SlateBlue;")
    slate_gray = Style("color: SlateGray;")
    slate_grey = Style("color: SlateGrey;")
    snow = Style("color: Snow;")
    spring_green = Style("color: SpringGreen;")
    steel_blue = Style("color: SteelBlue;")
    tan = Style("color: Tan;")
    teal = Style("color: Teal;")
    thistle = Style("color: Thistle;")
    tomato = Style("color: Tomato;")
    turquoise = Style("color: Turquoise;")
    violet = Style("color: Violet;")
    wheat = Style("color: Wheat;")
    white = Style("color: White;")
    white_smoke = Style("color: WhiteSmoke;")
    yellow = Style("color: Yellow;")
    yellow_green = Style("color: YellowGreen;")


class Sizes:
            @staticmethod
            def size(size: Union[str, int] = 16):
                """Creates a text  style with the specified size, default unit is pt"""
                # Convert integer size to pt-based string
                if type(size) is int:
                    size = str(size) + "pt"

                return Style(f"font-size: {size};")
            
            Giant_em_size = Style("font-size: 8em;")
            """8em"""
            giant_em_size = Style("font-size: 7em;")
            """7em"""
            Huge_em_size = Style("font-size: 6em;")
            """6em"""
            huge_em_size = Style("font-size: 5em;")
            """5em"""
            LARGE_em_size = Style("font-size: 4em;")
            """4em"""
            Large_em_size = Style("font-size: 3em;")
            """3em"""
            large_em_size = Style("font-size: 2em;")
            """2em"""
            big_em_size = Style("font-size: 1.5em;")
            """1.5em"""
            medium_em_size = Style("font-size: 1em;")
            """1em"""
            little_em_size = Style("font-size: 0.75em;")
            """0.75em"""
            small_em_size = Style("font-size: 0.5em;")
            """0.5em"""
            tiny_em_size = Style("font-size: 0.25em;")
            """0.25em"""
            
            Giant_px_size = Style("font-size: 128px;")
            """128px"""
            giant_px_size = Style("font-size: 112px;")
            """112px"""
            Huge_px_size = Style("font-size: 96px;")
            """96px"""
            huge_px_size = Style("font-size: 80px;")
            """80px"""
            LARGE_px_size = Style("font-size: 64px;")
            """64px"""
            Large_px_size = Style("font-size: 48px;")
            """48px"""
            large_px_size = Style("font-size: 32px;")
            """32px"""
            big_px_size = Style("font-size: 24px;")
            """24px"""
            medium_px_size = Style("font-size: 16px;")
            """16px"""
            little_px_size = Style("font-size: 12px;")
            """12px"""
            small_px_size = Style("font-size: 8px;")
            """8px"""
            tiny_px_size = Style("font-size: 4px;")
            """4px"""

            GIANT_size = Style("font-size: 196pt;")
            """196pt"""
            Giant_size = Style("font-size: 128pt;")
            """128pt"""
            giant_size = Style("font-size: 112pt;")
            """112pt"""
            Huge_size = Style("font-size: 96pt;")
            """96pt"""
            huge_size = Style("font-size: 80pt;")
            """80pt"""
            LARGE_size = Style("font-size: 64pt;")
            """64pt"""
            Large_size = Style("font-size: 48pt;")
            """48pt"""
            large_size = Style("font-size: 32pt;")
            """32pt"""
            big_size = Style("font-size: 24pt;")
            """24pt"""
            medium_size = Style("font-size: 16pt;")
            """16pt"""
            little_size = Style("font-size: 12pt;")
            """12pt"""
            small_size = Style("font-size: 8pt;")
            """8pt"""
            tiny_size = Style("font-size: 4pt;")
            """4pt"""

class Fonts:
     # Sans-serif fonts
    font_arial = Style("font-family: Arial; font-style: normal;")
    font_helvetica = Style("font-family: Helvetica; font-style: normal;")
    font_verdana = Style("font-family: Verdana; font-style: normal;")
    font_tahoma = Style("font-family: Tahoma; font-style: normal;")
    font_trebuchet_ms = Style("font-family: 'Trebuchet MS'; font-style: normal;")
    font_gill_sans = Style("font-family: 'Gill Sans'; font-style: normal;")

    # Serif fonts
    font_times_new_roman = Style("font-family: 'Times New Roman'; font-style: normal;")
    font_georgia = Style("font-family: Georgia; font-style: normal;")
    font_garamond = Style("font-family: Garamond; font-style: normal;")
    font_baskerville = Style("font-family: Baskerville; font-style: normal;")
    font_caslon = Style("font-family: Caslon; font-style: normal;")
    font_book_antiqua = Style("font-family: 'Book Antiqua'; font-style: normal;")
    
    # Monospace fonts
    font_courier_new = Style("font-family: 'Courier New'; font-style: normal;")
    font_lucida_console = Style("font-family: 'Lucida Console'; font-style: normal;")
    font_monaco = Style("font-family: Monaco; font-style: normal;")
    font_consolas = Style("font-family: Consolas; font-style: normal;")

    # Cursive fonts
    font_comic_sans_ms = Style("font-family: 'Comic Sans MS'; font-style: normal;")
    font_brush_script_mt = Style("font-family: 'Brush Script MT'; font-style: normal;")

    # Fantasy fonts
    font_impact = Style("font-family: Impact; font-style: normal;")
    font_luminari = Style("font-family: Luminari; font-style: normal;")
    font_chalkduster = Style("font-family: Chalkduster; font-style: normal;")

    # System UI fonts
    font_system_ui = Style("font-family: system-ui; font-style: normal;")
    font_segoe_ui = Style("font-family: 'Segoe UI'; font-style: normal;")
    font_apple_system = Style("font-family: -apple-system; font-style: normal;")
    font_sans_serif = Style("font-family: sans-serif; font-style: normal;")
    font_serif = Style("font-family: serif; font-style: normal;")
    font_monospace = Style("font-family: monospace; font-style: normal;")

class BackgroundColors:
	# Background colors
	reset_bg = Style("background-color: initial;")
	alice_blue_bg = Style("background-color: AliceBlue;")
	antique_white_bg = Style("background-color: AntiqueWhite;")
	aqua_bg = Style("background-color: Aqua;")
	aquamarine_bg = Style("background-color: Aquamarine;")
	azure_bg = Style("background-color: Azure;")
	beige_bg = Style("background-color: Beige;")
	bisque_bg = Style("background-color: Bisque;")
	black_bg = Style("background-color: Black;")
	blanched_almond_bg = Style("background-color: BlanchedAlmond;")
	blue_bg = Style("background-color: Blue;")
	blue_violet_bg = Style("background-color: BlueViolet;")
	brown_bg = Style("background-color: Brown;")
	burly_wood_bg = Style("background-color: BurlyWood;")
	cadet_blue_bg = Style("background-color: CadetBlue;")
	chartreuse_bg = Style("background-color: Chartreuse;")
	chocolate_bg = Style("background-color: Chocolate;")
	coral_bg = Style("background-color: Coral;")
	cornflower_blue_bg = Style("background-color: CornflowerBlue;")
	cornsilk_bg = Style("background-color: Cornsilk;")
	crimson_bg = Style("background-color: Crimson;")
	cyan_bg = Style("background-color: Cyan;")
	dark_blue_bg = Style("background-color: DarkBlue;")
	dark_cyan_bg = Style("background-color: DarkCyan;")
	dark_golden_rod_bg = Style("background-color: DarkGoldenRod;")
	dark_gray_bg = Style("background-color: DarkGray;")
	dark_grey_bg = Style("background-color: DarkGrey;")
	dark_green_bg = Style("background-color: DarkGreen;")
	dark_khaki_bg = Style("background-color: DarkKhaki;")
	dark_magenta_bg = Style("background-color: DarkMagenta;")
	dark_olive_green_bg = Style("background-color: DarkOliveGreen;")
	dark_orange_bg = Style("background-color: DarkOrange;")
	dark_orchid_bg = Style("background-color: DarkOrchid;")
	dark_red_bg = Style("background-color: DarkRed;")
	dark_salmon_bg = Style("background-color: DarkSalmon;")
	dark_sea_green_bg = Style("background-color: DarkSeaGreen;")
	dark_slate_blue_bg = Style("background-color: DarkSlateBlue;")
	dark_slate_gray_bg = Style("background-color: DarkSlateGray;")
	dark_slate_grey_bg = Style("background-color: DarkSlateGrey;")
	dark_turquoise_bg = Style("background-color: DarkTurquoise;")
	dark_violet_bg = Style("background-color: DarkViolet;")
	deep_pink_bg = Style("background-color: DeepPink;")
	deep_sky_blue_bg = Style("background-color: DeepSkyBlue;")
	dim_gray_bg = Style("background-color: DimGray;")
	dim_grey_bg = Style("background-color: DimGrey;")
	dodger_blue_bg = Style("background-color: DodgerBlue;")
	fire_brick_bg = Style("background-color: FireBrick;")
	floral_white_bg = Style("background-color: FloralWhite;")
	forest_green_bg = Style("background-color: ForestGreen;")
	fuchsia_bg = Style("background-color: Fuchsia;")
	gainsboro_bg = Style("background-color: Gainsboro;")
	ghost_white_bg = Style("background-color: GhostWhite;")
	gold_bg = Style("background-color: Gold;")
	golden_rod_bg = Style("background-color: GoldenRod;")
	gray_bg = Style("background-color: Gray;")
	grey_bg = Style("background-color: Grey;")
	green_bg = Style("background-color: Green;")
	green_yellow_bg = Style("background-color: GreenYellow;")
	honey_dew_bg = Style("background-color: HoneyDew;")
	hot_pink_bg = Style("background-color: HotPink;")
	indian_red_bg = Style("background-color: IndianRed;")
	indigo_bg = Style("background-color: Indigo;")
	ivory_bg = Style("background-color: Ivory;")
	khaki_bg = Style("background-color: Khaki;")
	lavender_bg = Style("background-color: Lavender;")
	lavender_blush_bg = Style("background-color: LavenderBlush;")
	lawn_green_bg = Style("background-color: LawnGreen;")
	lemon_chiffon_bg = Style("background-color: LemonChiffon;")
	light_blue_bg = Style("background-color: LightBlue;")
	light_coral_bg = Style("background-color: LightCoral;")
	light_cyan_bg = Style("background-color: LightCyan;")
	light_golden_rod_yellow_bg = Style("background-color: LightGoldenRodYellow;")
	light_gray_bg = Style("background-color: LightGray;")
	light_grey_bg = Style("background-color: LightGrey;")
	light_green_bg = Style("background-color: LightGreen;")
	light_pink_bg = Style("background-color: LightPink;")
	light_salmon_bg = Style("background-color: LightSalmon;")
	light_sea_green_bg = Style("background-color: LightSeaGreen;")
	light_sky_blue_bg = Style("background-color: LightSkyBlue;")
	light_slate_gray_bg = Style("background-color: LightSlateGray;")
	light_slate_grey_bg = Style("background-color: LightSlateGrey;")
	light_steel_blue_bg = Style("background-color: LightSteelBlue;")
	light_yellow_bg = Style("background-color: LightYellow;")
	lime_bg = Style("background-color: Lime;")
	lime_green_bg = Style("background-color: LimeGreen;")
	linen_bg = Style("background-color: Linen;")
	magenta_bg = Style("background-color: Magenta;")
	maroon_bg = Style("background-color: Maroon;")
	medium_aqua_marine_bg = Style("background-color: MediumAquaMarine;")
	medium_blue_bg = Style("background-color: MediumBlue;")
	medium_orchid_bg = Style("background-color: MediumOrchid;")
	medium_purple_bg = Style("background-color: MediumPurple;")
	medium_sea_green_bg = Style("background-color: MediumSeaGreen;")
	medium_slate_blue_bg = Style("background-color: MediumSlateBlue;")
	medium_spring_green_bg = Style("background-color: MediumSpringGreen;")
	medium_turquoise_bg = Style("background-color: MediumTurquoise;")
	medium_violet_red_bg = Style("background-color: MediumVioletRed;")
	midnight_blue_bg = Style("background-color: MidnightBlue;")
	mint_cream_bg = Style("background-color: MintCream;")
	misty_rose_bg = Style("background-color: MistyRose;")
	moccasin_bg = Style("background-color: Moccasin;")
	navajo_white_bg = Style("background-color: NavajoWhite;")
	navy_bg = Style("background-color: Navy;")
	old_lace_bg = Style("background-color: OldLace;")
	olive_bg = Style("background-color: Olive;")
	olive_drab_bg = Style("background-color: OliveDrab;")
	orange_bg = Style("background-color: Orange;")
	orange_red_bg = Style("background-color: OrangeRed;")
	orchid_bg = Style("background-color: Orchid;")
	pale_golden_rod_bg = Style("background-color: PaleGoldenRod;")
	pale_green_bg = Style("background-color: PaleGreen;")
	pale_turquoise_bg = Style("background-color: PaleTurquoise;")
	pale_violet_red_bg = Style("background-color: PaleVioletRed;")
	papaya_whip_bg = Style("background-color: PapayaWhip;")
	peach_puff_bg = Style("background-color: PeachPuff;")
	peru_bg = Style("background-color: Peru;")
	pink_bg = Style("background-color: Pink;")
	plum_bg = Style("background-color: Plum;")
	powder_blue_bg = Style("background-color: PowderBlue;")
	purple_bg = Style("background-color: Purple;")
	rebecca_purple_bg = Style("background-color: RebeccaPurple;")
	red_bg = Style("background-color: Red;")
	rosy_brown_bg = Style("background-color: RosyBrown;")
	royal_blue_bg = Style("background-color: RoyalBlue;")
	saddle_brown_bg = Style("background-color: SaddleBrown;")
	salmon_bg = Style("background-color: Salmon;")
	sandy_brown_bg = Style("background-color: SandyBrown;")
	sea_green_bg = Style("background-color: SeaGreen;")
	sea_shell_bg = Style("background-color: SeaShell;")
	sienna_bg = Style("background-color: Sienna;")
	silver_bg = Style("background-color: Silver;")
	sky_blue_bg = Style("background-color: SkyBlue;")
	slate_blue_bg = Style("background-color: SlateBlue;")
	slate_gray_bg = Style("background-color: SlateGray;")
	slate_grey_bg = Style("background-color: SlateGrey;")
	snow_bg = Style("background-color: Snow;")
	spring_green_bg = Style("background-color: SpringGreen;")
	steel_blue_bg = Style("background-color: SteelBlue;")
	tan_bg = Style("background-color: Tan;")
	teal_bg = Style("background-color: Teal;")
	thistle_bg = Style("background-color: Thistle;")
	tomato_bg = Style("background-color: Tomato;")
	turquoise_bg = Style("background-color: Turquoise;")
	violet_bg = Style("background-color: Violet;")
	wheat_bg = Style("background-color: Wheat;")
	white_bg = Style("background-color: White;")
	white_smoke_bg = Style("background-color: WhiteSmoke;")
	yellow_bg = Style("background-color: Yellow;")
	yellow_green_bg = Style("background-color: YellowGreen;")


class Paddings:

    @staticmethod
    def size(*sizes: Union[str, int]):
        """
        Creates a padding style with specified sizes, supporting 1-4 values as per CSS convention:
        - 1 value: Applies to all sides.
        - 2 values: top-bottom | left-right.
        - 3 values: top | left-right | bottom.
        - 4 values: top | right | bottom | left.

        :param sizes: Up to 4 values representing padding sizes (int value defaults to em)
        :return: Style object with the appropriate padding CSS property.
        """
        # Convert integers to em-based strings
        converted_sizes = []
        for size in sizes[:4]:
            if isinstance(size, int):
                size = f"{size}em"
            converted_sizes.append(str(size))

        # Join sizes into a single CSS padding property
        padding_value = " ".join(converted_sizes)
        return Style(f"padding: {padding_value};")
    
    # Padding
    Giant_padding = Style("padding: 8em;")
    """8em"""
    giant_padding = Style("padding: 7em;")
    """7em"""
    Huge_padding = Style("padding: 6em;")
    """6em"""
    huge_padding = Style("padding: 5em;")
    """5em"""
    LARGE_padding = Style("padding: 4em;")
    """4em"""
    Large_padding = Style("padding: 3em;")
    """3em"""
    large_padding = Style("padding: 2em;")
    """2em"""
    big_padding = Style("padding: 1.5em;")
    """1.5em"""
    medium_padding = Style("padding: 1em;")
    """1em"""
    little_padding = Style("padding: 0.75em;")
    """0.75em"""
    small_padding = Style("padding: 0.5em;")
    """0.5em"""
    tiny_padding = Style("padding: 0.25em;")
    """0.25em"""
    none_padding = Style("padding: 0px;")

class Margins:
    @staticmethod
    def size(*sizes: Union[str, int]):
        """
        Creates a margin style with specified sizes, supporting 1-4 values as per CSS convention:
        - 1 value: Applies to all sides.
        - 2 values: top-bottom | left-right.
        - 3 values: top | left-right | bottom.
        - 4 values: top | right | bottom | left.

        :param sizes: Up to 4 values representing margin sizes (int value defaults to em)
        :return: Style object with the appropriate margin CSS property.
        """
        # Convert integers to em-based strings
        converted_sizes = []
        for size in sizes[:4]:
            if isinstance(size, int):
                size = f"{size}em"
            converted_sizes.append(str(size))

        # Join sizes into a single CSS margin property
        margin_value = " ".join(converted_sizes)
        return Style(f"margin: {margin_value};")
    # Margin
    Giant_margin = Style("margin: 8em;")
    """8em"""
    giant_margin = Style("margin: 7em;")
    """7em"""
    Huge_margin = Style("margin: 6em;")
    """6em"""
    huge_margin = Style("margin: 5em;")
    """5em"""
    LARGE_margin = Style("margin: 4em;")
    """4em"""
    Large_margin = Style("margin: 3em;")
    """3em"""
    large_margin = Style("margin: 2em;")
    """2em"""
    big_margin = Style("margin: 1.5em;")
    """1.5em"""
    medium_margin = Style("margin: 1em;")
    """1em"""
    little_margin = Style("margin: 0.75em;")
    """0.75em"""
    small_margin = Style("margin: 0.5em;")
    """0.5em"""
    tiny_margin = Style("margin: 0.25em;")
    """0.25em"""
    none_margin = Style("margin: 0px;")
    auto_margin = Style("margin: auto;")

class Layouts:
    # Layout styles
    fix_ratio = Style("display: block;")
    inline = Style("display: inline-block;")
    col_layout = Style("display: flex; flex-direction: column;")
    row_layout = Style("display: flex; flex-direction: row;")
    vertical_center_layout = Style("display: flex; align-items: center; justify-content: center;")
    table_layout = Style("table-layout: fixed; width: 100%;")

class ContainerSizes:
    # Width and height
    width_full = Style("width: 100%;")
    width_half = Style("width: 50%;")
    width_auto = Style("width: auto;")

    height_full = Style("height: 100%;")
    height_half = Style("height: 50%;")
    height_auto = Style("height: auto;")

class Borders:
  
    # Border widths
    @staticmethod
    def size(*sizes: Union[str, int]):
        """
        Creates a border width style with specified sizes, supporting 1-4 values as per CSS convention:
        - 1 value: Applies to all sides.
        - 2 values: top-bottom | left-right.
        - 3 values: top | left-right | bottom.
        - 4 values: top | right | bottom | left.

        :param sizes: Up to 4 values representing border width sizes (int value defaults to em)
        :return: Style object with the appropriate border width CSS property.
        """
        # Convert integers to em-based strings
        converted_sizes = []
        for size in sizes[:4]:
            if isinstance(size, int):
                size = f"{size}em"
            converted_sizes.append(str(size))

        # Join sizes into a single CSS border width property
        border_width_value = " ".join(converted_sizes)
        return Style(f"border-width: {border_width_value};")
    
    thin_border = Style("border-width: thin;")
    medium_border = Style("border-width: medium;")
    thick_border = Style("border-width: thick;")

    # Border style
    solid_border = Style("border-style: solid;")
    dotted_border = Style("border-style: dotted;")
    dashed_border = Style("border-style: dashed;")
    double_border = Style("border-style: double;")
    groove_border = Style("border-style: groove;")
    ridge_border = Style("border-style: ridge;")
    inset_border = Style("border-style: inset;")
    outset_border = Style("border-style: outset;")
    none_border = Style("border-style: none;")
    hidden_border = Style("border-style: hidden;")

    @staticmethod
    def color(color: Union[Style, str]):
        """
        Converts a text color Style object or string into a border color Style.
        If the input is a Style object with a 'color' property, it extracts and transforms it.
        
        :param color: A Style object or a color string.
        :return: A Style object with 'border-color' set.
        """
        if isinstance(color, Style):
            color_str = str(color)
            if "color:" in color_str:
                # Extract color name or value from 'color: ...;'
                color = color_str.split("color:")[1].split(";")[0]

        return Style(f"border-color: {color};")
            
    table_border = Style("""border: 1px solid rgba(0, 0, 0, 1);
                            border-collapse: collapse;
                            opacity: 1;""")

class Flex:
    # Flexbox layouts
    flex = Style("display:flex;")
    row_flex = Style("display: flex; flex-direction: row;")
    col_flex = Style("display: flex; flex-direction: column;")
    wrap_flex = Style("display: flex; flex-wrap: wrap;")

    space_between_justify = Style("justify-content: space-between;")
    center_justify = Style("justify-content: center;")
    center_align_items = Style("align-items: center;")
    center_flex = flex + center_align_items
    
class Visibility:
    # Display and visibility
    hidden = Style("display: none;")
    """block doesn't take up space in page"""
    visible = Style("visibility: visible;")
    invisible = Style("visibility: hidden;")
    """block takes up space in page"""


class ListStyles:
      g_docs = ListStyle(symbols=["❖", "➢", "◼", "●", "◆", "➢", "◼", "●", "◆", "◆", "◆", "◆", "◆", "◆", "◆", "◆"])
      ordered_lowercase = Style("list-style-type: lower-alpha;")

class Titles:
    # Titles and Subtitles
    title =     Weights.bold_weight + Sizes.LARGE_size + Alignments.center_align
    subtitle =  Weights.bold_weight + Sizes.large_size  + Alignments.center_align

    


class Text:
    decors = Decors
    weights = Weights
    alignments = Alignments
    colors = Colors
    bg_colors = BackgroundColors
    sizes = Sizes
    fonts = Fonts
    titles = Titles


class Positions:
    # CSS position properties
    initial = Style("position: initial;")
    static = Style("position: static;")
    relative = Style("position: relative;")
    absolute = Style("position: absolute;")
    fixed = Style("position: fixed;")
    sticky = Style("position: sticky;") 

    # Position offsets (only work with relative, absolute, and sticky)
    @staticmethod
    def top(offset: Union[str, int]):
        # Convert integer size to px-based string
        if type(offset) is int:
            offset = str(offset) + "px"

        return Style(f"top: {offset};")
    
    @staticmethod
    def bottom(offset: Union[str, int]):
        # Convert integer size to px-based string
        if type(offset) is int:
            offset = str(offset) + "px"

        return Style(f"bottom: {offset};")
    
    @staticmethod
    def left(offset: Union[str, int]):
        # Convert integer size to px-based string
        if type(offset) is int:
            offset = str(offset) + "px"

        return Style(f"left: {offset};")
    
    @staticmethod
    def right(offset: Union[str, int]):
        # Convert integer size to px-based string
        if type(offset) is int:
            offset = str(offset) + "px"

        return Style(f"right: {offset};")


class Container:
    sizes = ContainerSizes
    bg_colors = BackgroundColors
    borders = Borders
    paddings = Paddings
    margins = Margins
    layouts = Layouts
    flex = Flex
    lists = ListStyles
    positions = Positions
           

text = Text  
container = Container
visibility = Visibility  



class StreamTeX_Styles:

    ### Enums #####
    none = Style("")    
    text = Text
    container = Container
    visibility = Visibility

    bold = text.weights.bold_weight
    reset_bold = text.weights.normal_weight
    italic = text.decors.italic_text
    center_txt = text.alignments.center_align


    GIANT = text.sizes.GIANT_size
    """196pt"""
    Giant = text.sizes.Giant_size
    """128pt"""
    giant = text.sizes.giant_size
    """112pt"""
    Huge = text.sizes.Huge_size
    """96pt"""
    huge = text.sizes.huge_size
    """80pt"""
    LARGE = text.sizes.LARGE_size
    """64pt"""
    Large = text.sizes.Large_size
    """48pt"""
    large = text.sizes.large_size
    """32pt"""
    big = text.sizes.big_size
    """24pt"""
    medium = text.sizes.medium_size
    """16pt"""
    little = text.sizes.little_size
    """12pt"""
    small = text.sizes.small_size
    """8pt"""
    tiny = text.sizes.tiny_size
    """4pt"""
        