import streamlit as st
from streamtex import Styles as s


class StreamTeX_ToC:
    def __init__(self, toc_list: list = [], numerate_title:bool = True, toc_bck_index = -1):
        # TODO: point style like google docs
        self.toc_list = toc_list
        self.numerate_title = numerate_title
        self.current_level = 1
        self.numbers = []
        self.toc_bck_index = toc_bck_index
        
        self.toc_title_style = s.text.titles.title
        self.toc_content_style = s.text.titles.subtitle

    
    def add_section(self, level: str, title: str):
        """level can be '+x' or '-x' for relative TOC levels, or just 'x' for absolute TOC levels."""

        if level.startswith("+") or level.startswith("-"):
            lvl = self.current_level + int(level)
            lvl = max(lvl, 1)
        else:
            lvl = int(level)
            lvl = max(lvl, 1)
            self.current_level = lvl

         # Update section numbering
        while len(self.numbers) < lvl:
            self.numbers.append(0)  # Extend numbering hierarchy
        self.numbers = self.numbers[:lvl]  # Trim unused levels
        self.numbers[-1] += 1  # Increment the current level number

        # Reset numbering for subsequent levels when jumping back in hierarchy
        if len(self.numbers) > lvl:
            self.numbers = self.numbers[:lvl]

        # Generate numbering if numeration is enabled
        section_number = ".".join(map(str, self.numbers)) + " "

        # Add to the ToC list
        toc_entry = {
            "level": lvl,
            "title": section_number + title if self.numerate_title else title,
            "key_anchor": self.get_key_anchor(section_number + title),
        }
        self.toc_list.append(toc_entry)
        
        if not self.numerate_title:
            section_number = ""

        return toc_entry["key_anchor"], section_number
    
    def generate(self, indent_char="&nbsp;"):
        toc_string = ""
        for entry in self.toc_list:
            indentation = indent_char * 4 * (entry["level"] - 1)
            # OLD AF - st.sidebar.markdown(f'<span style="overflow: hidden; text-overflow: ellipsis; text-wrap: nowrap; word-wrap: normal;">{indentation}<a href="#{entry['key_anchor']}">{entry['title']}</a></span>', unsafe_allow_html=True)
            st.sidebar.markdown(
                f"<span style=\"overflow: hidden; text-overflow: ellipsis; text-wrap: nowrap; word-wrap: normal;\">"
                f"{indentation}<a href=\"#{entry['key_anchor']}\">{entry['title']}</a></span>",
                unsafe_allow_html=True
            )
        return toc_string
    
    @staticmethod
    def get_key_anchor(title: str):
        return title.replace('.', '-').replace(' ', '-').lower()
        
                    
