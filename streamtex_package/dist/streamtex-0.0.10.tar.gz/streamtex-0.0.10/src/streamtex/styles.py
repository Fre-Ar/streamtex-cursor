from typing import List, Tuple, Optional, Type
import re

theme = None

def add_css(str1: str, str2: str):
    if str1 and str2:
         return str1 + "; " + str2
    elif str1:
         return str1
    else:
         return str2
    
def remove_css(str1: str, str2: str):
    # Split CSS strings into lists of properties
    props1 = [prop.strip() for prop in str1.split(';') if prop.strip()]
    props2 = [prop.strip() for prop in str2.split(';') if prop.strip()]

    # Extract property names from props2
    prop_names2 = set()
    for prop in props2:
        match = re.match(r'^([^:]+):', prop)
        if match:
            prop_name = match.group(1).strip()
            prop_names2.add(prop_name)

    # Remove properties from props1 that are in prop_names2
    new_props1 = []
    for prop in props1:
        match = re.match(r'^([^:]+):', prop)
        if match:
            prop_name = match.group(1).strip()
            if prop_name not in prop_names2:
                new_props1.append(prop)
        else:
            # Keep properties without a colon (malformed)
            new_props1.append(prop)

    return '; '.join(new_props1)

class Style:
    """Defines a style, encapsulating a string of (maybe) multiple css in-line styles"""
    def __init__(self, css:str, theme_css: dict={}):
        self.css = css
        self.theme_css = theme_css

     # Define addition
    def __add__(self, other):
        if isinstance(other, Style):
            
            # Merge theme_css dictionaries
            new_theme_css = {
                key: add_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            # Combine two Style objects
            return Style( add_css(self.css,  other.css), new_theme_css)
        elif isinstance(other, str):
            # Combine Style object with a string (CSS string)
            return Style( add_css(self.css, other), self.theme_css)
        return NotImplemented

    # Define reverse addition
    def __radd__(self, other):
        if isinstance(other, str):
            # Allow a string to be added before a Style object
            return Style( add_css( other, self.css), self.theme_css)
        return NotImplemented
    
    # Define subtraction
    def __sub__(self, other):
        if isinstance(other, Style):
            # Remove other.css from self.css
            new_css = remove_css(self.css, other.css)
                        # Subtract theme_css dictionaries
            new_theme_css = {
                key: remove_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }

            return Style(new_css, new_theme_css)
        elif isinstance(other, str):
            # Remove CSS string from self.css
            new_css = remove_css(self.css, other)
            return Style(new_css, self.theme_css)
        return NotImplemented

    # Define reverse subtraction
    def __rsub__(self, other):
        if isinstance(other, str):
            # Remove self.css from other CSS string
            new_css = remove_css(other, self.css)
            return Style(new_css, self.theme_css)
        return NotImplemented
    
    def __bool__(self):
        # Return False if the css string is empty or only whitespace
        return bool(self.css.strip())
    
    def __repr__(self):
        # Return the thematic style, otherwise the default css
        return self.theme_css.get(theme, self.css) 

class ListStyle(Style):
    """Defines a style for lists, including CSS and custom list symbols for styling levels."""
    def __init__(self, css: str = "", theme_css: dict = {}, symbols: List[str] = ["●"]):
        super().__init__(css, theme_css)
        self.symbols = symbols

    # Define addition
    def __add__(self, other):
        if isinstance(other, Style):
            # Combine two Style objects, including theme_css and symbols
            new_css = add_css(self.css, other.css)
            new_theme_css = {
                key: add_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            new_symbols = self.symbols + (other.symbols if isinstance(other, ListStyle) else [])
            return ListStyle(new_css, new_theme_css, new_symbols)
        elif isinstance(other, str):
            # Combine ListStyle with a CSS string
            return ListStyle(add_css(self.css, other), self.theme_css, self.symbols)
        return NotImplemented

    # Define reverse addition
    def __radd__(self, other):
        if isinstance(other, str):
            # Allow a string to be added before a ListStyle object
            return ListStyle(add_css(other, self.css), self.theme_css, self.symbols)
        return NotImplemented

    # Define subtraction
    def __sub__(self, other):
        if isinstance(other, Style):
            # Remove other.css from self.css and handle theme_css and symbols
            new_css = remove_css(self.css, other.css)
            new_theme_css = {
                key: remove_css(self.theme_css.get(key, ""), other.theme_css.get(key, ""))
                for key in set(self.theme_css.keys()).union(other.theme_css.keys())
            }
            new_symbols = [s for s in self.symbols if not (isinstance(other, ListStyle) and s in other.symbols)]
            return ListStyle(new_css, new_theme_css, new_symbols)
        elif isinstance(other, str):
            # Remove a CSS string from self.css
            return ListStyle(remove_css(self.css, other), self.theme_css, self.symbols)
        return NotImplemented

    # Define reverse subtraction
    def __rsub__(self, other):
        if isinstance(other, str):
            # Remove self.css from another CSS string
            return ListStyle(remove_css(other, self.css), self.theme_css, self.symbols)
        return NotImplemented

    def lvl(self, lvl: int = 1):
        """
        Get the list-style type CSS for a specific level.
        Cycles through the symbols if the level exceeds the number of symbols.
        """
        index = (lvl - 1) % len(self.symbols)
        return f"list-style-type: '{self.symbols[index]}';"

class StyleGrid:
    """
    Defines a grid of styles that will be applied to the rows/columns of a table or grid.
    """

    def __init__(self, css_grid: List[List[Style]] = []):
        self.css_grid = css_grid

    def __add__(self, other):
        """
        Overlapping styles are added in the order of the style grids addition.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s1 + s2)
        
        elif isinstance(other, list):
            return self + StyleGrid(other)
        
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse addition: other + self
            return other + self
        
        elif isinstance(other, list):
            return StyleGrid(other) + self
        
        return NotImplemented
    

    def __sub__(self, other):
        """
        Overlapping styles are subtracted in the order of the style grids subtraction.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s1 - s2)
        elif isinstance(other, list):
            return self - StyleGrid(other)
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse subtraction: other - self
            return other - self
        elif isinstance(other, list):
            return StyleGrid(other) - self
        return NotImplemented

    def __mul__(self, other):
        """
        Multiplication works like addition but styles at the same cell are replaced.
        """
        if isinstance(other, StyleGrid):
            return self._combine_with(other, combine_styles=lambda s1, s2: s2 if s2 else s1)
        elif isinstance(other, list):
            return self * StyleGrid(other)
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, StyleGrid):
            # Reverse multiplication: other * self
            return other * self    
        elif isinstance(other, list):
            return StyleGrid(other) * self
        return NotImplemented

    def _combine_with(self, other, combine_styles):
        """
        Combines two StyleGrids using the provided combine_styles function for overlapping cells.
        """
        self_rows, self_cols = self._get_dimensions()
        other_rows, other_cols = other._get_dimensions()

        max_rows = max(self_rows, other_rows)
        max_cols = max(self_cols, other_cols)

        # Initialize new grid with Styles.none
        new_grid = [[StreamTeX_Styles.none for _ in range(max_cols)] for _ in range(max_rows)]

        # Fill in styles from self
        for i in range(self_rows):
            for j in range(len(self.css_grid[i])):
                new_grid[i][j] = self.css_grid[i][j]

        # Combine styles from other
        for i in range(other_rows):
            for j in range(len(other.css_grid[i])):
                if i < max_rows and j < max_cols:
                    new_grid[i][j] = combine_styles(new_grid[i][j], other.css_grid[i][j])

        return StyleGrid(new_grid)

    def _get_dimensions(self) -> Tuple[int, int]:
        if not self.css_grid:
            return 0, 0
        num_rows = len(self.css_grid)
        num_cols = max(len(row) for row in self.css_grid) if self.css_grid else 0
        return num_rows, num_cols

    @staticmethod
    def create(cells: str, style: Style, num_rows: Optional[int] = None, num_cols: Optional[int] = None):
        """
        Creates a StyleGrid with the specified cells filled with the given style.
        Cells are specified in Excel-like notation (e.g., "A1:C3,B5").
        Other cells are filled with Styles.none.
        """
        # Parse the cells string to get the list of cell indices
        cells_list = StyleGrid._parse_cells(cells)

        # Determine the required grid size
        max_row_index = max((row for row, _ in cells_list), default=0)
        max_col_index = max((col for _, col in cells_list), default=0)

        # Adjust grid size based on provided num_rows and num_cols
        grid_rows = max(num_rows if num_rows is not None else 0, max_row_index + 1)
        grid_cols = max(num_cols if num_cols is not None else 0, max_col_index + 1)

        # Initialize the grid with Styles.none
        grid = [[StreamTeX_Styles.none for _ in range(grid_cols)] for _ in range(grid_rows)]

        # Fill in the specified cells with the given style
        for row, col in cells_list:
            if row < grid_rows and col < grid_cols:
                grid[row][col] = style

        return StyleGrid(grid)

    @staticmethod
    def _parse_cells(cells_str: str) -> List[Tuple[int, int]]:
        """
        Parses a string of cell ranges in Excel-like notation and returns a list of cell indices.
        """
        cells = []
        ranges = cells_str.split(',')
        for cell_range in ranges:
            cell_range = cell_range.strip()
            if ':' in cell_range:
                start_cell, end_cell = cell_range.split(':')
                start_row, start_col = StyleGrid._cell_to_indices(start_cell.strip())
                end_row, end_col = StyleGrid._cell_to_indices(end_cell.strip())

                # Swap if start is after end
                if start_row > end_row:
                    start_row, end_row = end_row, start_row
                if start_col > end_col:
                    start_col, end_col = end_col, start_col

                for row in range(start_row, end_row + 1):
                    for col in range(start_col, end_col + 1):
                        cells.append((row, col))
            else:
                row, col = StyleGrid._cell_to_indices(cell_range)
                cells.append((row, col))
        return cells

    @staticmethod
    def _cell_to_indices(cell: str) -> Tuple[int, int]:
        """
        Converts a cell reference (e.g., "A1") to zero-based (row, col) indices.
        """
        match = re.match(r'^([A-Za-z]+)([0-9]+)$', cell)
        if not match:
            raise ValueError(f"Invalid cell reference: {cell}")
        col_str, row_str = match.groups()
        col_index = StyleGrid._column_letter_to_index(col_str)
        row_index = int(row_str) - 1  # Convert to zero-based index
        return row_index, col_index

    @staticmethod
    def _column_letter_to_index(col_str: str) -> int:
        """
        Converts column letters to a zero-based column index.
        """
        col_str = col_str.upper()
        col_index = 0
        for char in col_str:
            if 'A' <= char <= 'Z':
                col_index = col_index * 26 + (ord(char) - ord('A') + 1)
            else:
                raise ValueError(f"Invalid column letter: {char}")
        return col_index - 1  # Convert to zero-based index



class Decors:
            # Font decoration
            italic_text = Style("font-style: italic;")
            underline_text = Style("text-decoration: underline;")
            decor_none_text = Style("text-decoration: none;")

class Weights:
            # Font weights
            bold_weight = Style("font-weight: bold;")
            light_weight = Style("font-weight: 300;")
            normal_weight = Style("font-weight: normal;")

class Alignments:
            # Text alignment (how multi-line text is aligned, not where it is positioned)
            center_align = Style("text-align: center;")
            right_align = Style("text-align: right;")
            left_align = Style("text-align: left;")

class Colors:
            # Basic color styles
            red_color = Style("color: red;")
            green_color = Style("color: green;")
            blue_color = Style("color: blue;")
            black_color = Style("color: black;")
            white_color = Style("color: white;")
            yellow_color = Style("color: yellow;")
            orange_color = Style("color: orange;")
            gray_color = Style("color: gray;")
            lime_color = Style("color: lime;")
            reset = Style("color: initial;")

class Sizes:
            Giant_em_size = Style("font-size: 8em;")
            """8em"""
            giant_em_size = Style("font-size: 7em;")
            """7em"""
            Huge_em_size = Style("font-size: 6em;")
            """6em"""
            huge_em_size = Style("font-size: 5em;")
            """5em"""
            LARGE_em_size = Style("font-size: 4em;")
            """4em"""
            Large_em_size = Style("font-size: 3em;")
            """3em"""
            large_em_size = Style("font-size: 2em;")
            """2em"""
            big_em_size = Style("font-size: 1.5em;")
            """1.5em"""
            medium_em_size = Style("font-size: 1em;")
            """1em"""
            little_em_size = Style("font-size: 0.75em;")
            """0.75em"""
            small_em_size = Style("font-size: 0.5em;")
            """0.5em"""
            tiny_em_size = Style("font-size: 0.25em;")
            """0.25em"""
            
            Giant_px_size = Style("font-size: 128px;")
            """128px"""
            giant_px_size = Style("font-size: 112px;")
            """112px"""
            Huge_px_size = Style("font-size: 96px;")
            """96px"""
            huge_px_size = Style("font-size: 80px;")
            """80px"""
            LARGE_px_size = Style("font-size: 64px;")
            """64px"""
            Large_px_size = Style("font-size: 48px;")
            """48px"""
            large_px_size = Style("font-size: 32px;")
            """32px"""
            big_px_size = Style("font-size: 24px;")
            """24px"""
            medium_px_size = Style("font-size: 16px;")
            """16px"""
            little_px_size = Style("font-size: 12px;")
            """12px"""
            small_px_size = Style("font-size: 8px;")
            """8px"""
            tiny_px_size = Style("font-size: 4px;")
            """4px"""

            GIANT_size = Style("font-size: 196pt;")
            """196pt"""
            Giant_size = Style("font-size: 128pt;")
            """128pt"""
            giant_size = Style("font-size: 112pt;")
            """112pt"""
            Huge_size = Style("font-size: 96pt;")
            """96pt"""
            huge_size = Style("font-size: 80pt;")
            """80pt"""
            LARGE_size = Style("font-size: 64pt;")
            """64pt"""
            Large_size = Style("font-size: 48pt;")
            """48pt"""
            large_size = Style("font-size: 32pt;")
            """32pt"""
            big_size = Style("font-size: 24pt;")
            """24pt"""
            medium_size = Style("font-size: 16pt;")
            """16pt"""
            little_size = Style("font-size: 12pt;")
            """12pt"""
            small_size = Style("font-size: 8pt;")
            """8pt"""
            tiny_size = Style("font-size: 4pt;")
            """4pt"""

class Fonts:
     # Sans-serif fonts
    font_arial = Style("font-family: Arial; font-style: normal;")
    font_helvetica = Style("font-family: Helvetica; font-style: normal;")
    font_verdana = Style("font-family: Verdana; font-style: normal;")
    font_tahoma = Style("font-family: Tahoma; font-style: normal;")
    font_trebuchet_ms = Style("font-family: 'Trebuchet MS'; font-style: normal;")
    font_gill_sans = Style("font-family: 'Gill Sans'; font-style: normal;")

    # Serif fonts
    font_times_new_roman = Style("font-family: 'Times New Roman'; font-style: normal;")
    font_georgia = Style("font-family: Georgia; font-style: normal;")
    font_garamond = Style("font-family: Garamond; font-style: normal;")
    font_baskerville = Style("font-family: Baskerville; font-style: normal;")
    font_caslon = Style("font-family: Caslon; font-style: normal;")
    font_book_antiqua = Style("font-family: 'Book Antiqua'; font-style: normal;")
    
    # Monospace fonts
    font_courier_new = Style("font-family: 'Courier New'; font-style: normal;")
    font_lucida_console = Style("font-family: 'Lucida Console'; font-style: normal;")
    font_monaco = Style("font-family: Monaco; font-style: normal;")
    font_consolas = Style("font-family: Consolas; font-style: normal;")

    # Cursive fonts
    font_comic_sans_ms = Style("font-family: 'Comic Sans MS'; font-style: normal;")
    font_brush_script_mt = Style("font-family: 'Brush Script MT'; font-style: normal;")

    # Fantasy fonts
    font_impact = Style("font-family: Impact; font-style: normal;")
    font_luminari = Style("font-family: Luminari; font-style: normal;")
    font_chalkduster = Style("font-family: Chalkduster; font-style: normal;")

    # System UI fonts
    font_system_ui = Style("font-family: system-ui; font-style: normal;")
    font_segoe_ui = Style("font-family: 'Segoe UI'; font-style: normal;")
    font_apple_system = Style("font-family: -apple-system; font-style: normal;")
    font_sans_serif = Style("font-family: sans-serif; font-style: normal;")
    font_serif = Style("font-family: serif; font-style: normal;")
    font_monospace = Style("font-family: monospace; font-style: normal;")

class Bg_Colors:
    # Background colors
    red_bg_color = Style("background-color: red;")
    green_bg_color = Style("background-color: green;")
    blue_bg_color = Style("background-color: blue;")
    yellow_bg_color = Style("background-color: yellow;")
    gray_bg_color = Style("background-color: gray;")
    black_bg_color = Style("background-color: black;")
    white_bg_color = Style("background-color: white;")
    orange_bg_color = Style("background-color: orange;")

class Paddings:
    # Padding
    Giant_padding = Style("padding: 8em;")
    """8em"""
    giant_padding = Style("padding: 7em;")
    """7em"""
    Huge_padding = Style("padding: 6em;")
    """6em"""
    huge_padding = Style("padding: 5em;")
    """5em"""
    LARGE_padding = Style("padding: 4em;")
    """4em"""
    Large_padding = Style("padding: 3em;")
    """3em"""
    large_padding = Style("padding: 2em;")
    """2em"""
    big_padding = Style("padding: 1.5em;")
    """1.5em"""
    medium_padding = Style("padding: 1em;")
    """1em"""
    little_padding = Style("padding: 0.75em;")
    """0.75em"""
    small_padding = Style("padding: 0.5em;")
    """0.5em"""
    tiny_padding = Style("padding: 0.25em;")
    """0.25em"""
    none_padding = Style("padding: 0px;")

class Margins:
    # Margin
    Giant_margin = Style("margin: 8em;")
    """8em"""
    giant_margin = Style("margin: 7em;")
    """7em"""
    Huge_margin = Style("margin: 6em;")
    """6em"""
    huge_margin = Style("margin: 5em;")
    """5em"""
    LARGE_margin = Style("margin: 4em;")
    """4em"""
    Large_margin = Style("margin: 3em;")
    """3em"""
    large_margin = Style("margin: 2em;")
    """2em"""
    big_margin = Style("margin: 1.5em;")
    """1.5em"""
    medium_margin = Style("margin: 1em;")
    """1em"""
    little_margin = Style("margin: 0.75em;")
    """0.75em"""
    small_margin = Style("margin: 0.5em;")
    """0.5em"""
    tiny_margin = Style("margin: 0.25em;")
    """0.25em"""
    none_margin = Style("margin: 0px;")
    auto_margin = Style("margin: auto;")

class Layouts:
    # Layout styles
    fix_ratio = Style("display: block;")
    inline = Style("display: inline-block;")
    col_layout = Style("display: flex; flex-direction: column;")
    row_layout = Style("display: flex; flex-direction: row;")
    vertical_center_layout = Style("display: flex; align-items: center; justify-content: center;")
    table_layout = Style("table-layout: fixed; width: 100%;")

class ContainerSizes:
    # Width and height
    width_full = Style("width: 100%;")
    width_half = Style("width: 50%;")
    width_auto = Style("width: auto;")

    height_full = Style("height: 100%;")
    height_half = Style("height: 50%;")
    height_auto = Style("height: auto;")

class Borders:
    # Borders 
    black_border = Style("border: 1px solid black;")
    red_border = Style  ("border: 2px solid red;")
    dashed_border = Style("border: 2px dashed black;")
    none_border = Style ("border: none;")
            
    table_border = Style("""border: 1px solid rgba(0, 0, 0, 1);
                            border-collapse: collapse;
                            opacity: 1;""")

class Flex:
    # Flexbox layouts
    flex = Style("""display:flex;""")
    row_flex = Style("display: flex; flex-direction: row;")
    col_flex = Style("display: flex; flex-direction: column;")
    wrap_flex = Style("display: flex; flex-wrap: wrap;")

    space_between_justify = Style("justify-content: space-between;")
    center_justify = Style("justify-content: center;")
    center_align_items = Style("align-items: center;")
    center_flex = flex + center_align_items
    
class Visibility:
    # Display and visibility
    hidden = Style("display: none;")
    """block doesn't take up space in page"""
    visible = Style("visibility: visible;")
    invisible = Style("visibility: hidden;")
    """block takes up space in page"""


class ListStyles:
      g_docs = ListStyle(symbols=["❖", "➢", "◼", "●", "◆", "➢", "◼", "●", "◆", "◆", "◆", "◆", "◆", "◆", "◆", "◆"])
      ordered_lowercase = Style("list-style-type: lower-alpha;")

class Titles:
    # Titles and Subtitles
    title =     Weights.bold_weight + Sizes.LARGE_size + Alignments.center_align
    subtitle =  Weights.bold_weight + Sizes.large_size  + Alignments.center_align


class Text:
    decors = Decors
    weights = Weights
    alignments = Alignments
    colors = Colors
    bg_colors = Bg_Colors
    sizes = Sizes
    fonts = Fonts
    titles = Titles

class Container:
    sizes = ContainerSizes
    bg_colors = Bg_Colors
    borders = Borders
    paddings = Paddings
    margins = Margins
    layouts = Layouts
    flex = Flex
    lists = ListStyles
           

text = Text  
container = Container
visibility = Visibility  



class StreamTeX_Styles:

    ### Enums #####
    none = Style("")    
    text = Text
    container = Container
    visibility = Visibility

    bold = text.weights.bold_weight
    reset_bold = text.weights.normal_weight
    italic = text.decors.italic_text
    center_txt = text.alignments.center_align


    GIANT = text.sizes.GIANT_size
    """196pt"""
    Giant = text.sizes.Giant_size
    """128pt"""
    giant = text.sizes.giant_size
    """112pt"""
    Huge = text.sizes.Huge_size
    """96pt"""
    huge = text.sizes.huge_size
    """80pt"""
    LARGE = text.sizes.LARGE_size
    """64pt"""
    Large = text.sizes.Large_size
    """48pt"""
    large = text.sizes.large_size
    """32pt"""
    big = text.sizes.big_size
    """24pt"""
    medium = text.sizes.medium_size
    """16pt"""
    little = text.sizes.little_size
    """12pt"""
    small = text.sizes.small_size
    """8pt"""
    tiny = text.sizes.tiny_size
    """4pt"""
        